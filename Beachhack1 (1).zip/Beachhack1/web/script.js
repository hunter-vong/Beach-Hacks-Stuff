let backButtonCreated = false;

function submitISBN() {
    const isbn = document.getElementById('isbn').value;
    if (isbn) {
        // Fetch book information from the Google Books API
        fetch(`https://www.googleapis.com/books/v1/volumes?q=isbn:${isbn}`)
            .then(response => response.json())
            .then(data => {
                if (data.items && data.items.length > 0) {
                    const book = data.items[0].volumeInfo;
                    
                    // Extract relevant book details
                    const title = book.title || "No title available";
                    const author = book.authors ? book.authors.join(', ') : "No author information available";
                    const description = book.description || "No description available";
                    const imageUrl = book.imageLinks ? book.imageLinks.thumbnail : null;
                    
                    // Display the book information
                    document.getElementById('book-title').textContent = title;
                    document.getElementById('book-author').textContent = "Author(s): " + author;
                    document.getElementById('book-description').textContent = description;
                    
                    // Display book cover image if available
                    const bookImageElement = document.getElementById('book-image');
                    if (imageUrl) {
                        bookImageElement.src = imageUrl;
                        bookImageElement.style.display = 'block'; // Make sure the image is shown
                    } else {
                        bookImageElement.style.display = 'none'; // Hide image if not available
                    }
                    
                    // Show the book info container
                    document.getElementById('book-info').style.display = 'block';
                } else {
                    alert("No book found for this ISBN.");
                }
            })
            .catch(error => {
                alert("Error fetching book information.");
                console.error(error);
            });
    } else {
        alert("Please enter an ISBN number.");
    }
}

// Function to change the first bar content
function changeBarContent() {
    // Change the ISBN label text to "Search Book using ISBN Number"
    document.getElementById('isbn-label-text').innerHTML = 'Search Book Using ISBN Number';
    
    document.querySelector('.right-side').style.display = 'none';
    
    // Removed the back button logic as per your request
}

// Function to reset the bar content back to original
function resetBarContent() {
    // Reset the label text back to "Enter ISBN Number"
    document.getElementById('isbn-label-text').innerHTML = 'Enter ISBN Number';
    
    // Hide the "Back" button
    const backButton = document.querySelector('.right-side[onclick="resetBarContent()"]');
    if (backButton) {
        backButton.remove();
    }
    
    // Show the "DAIN AI" button again in its original place
    document.querySelector('.right-side').style.display = 'flex';
    
    // Reset the backButtonCreated flag
    backButtonCreated = false;
}
